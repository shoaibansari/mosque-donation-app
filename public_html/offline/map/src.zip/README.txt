A Pen created at CodePen.io. You can find this one at https://codepen.io/Marnoto/pen/xboPmG.

 How you can create an infowindow header, repositioning of its tail, change the infowindow size and background color, give a new look to the infowindow close button, rounded corners and a fade effect.
Full explanation: http://en.marnoto.com/2014/09/5-formas-de-personalizar-infowindow.html